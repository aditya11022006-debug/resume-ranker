#!/usr/bin/env python3
"""
Resume Screener & Candidate Ranker

Usage:
    python resume_ranker.py --job job.json --resumes ./resumes --out ranking.csv

Supports .txt, .md, .pdf (pip install pypdf), .docx (pip install python-docx).
Core scoring needs only the standard library.

Scoring (weights configurable in job.json):
    required skills coverage, nice-to-have skills, TF-IDF similarity to the
    job description, years of experience, education level.

Fairness note: names, photos, gender, age and address are never used. Candidates
are identified by file name. Treat the output as a shortlist aid, not a decision.
"""
import argparse
import csv
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path

DEFAULT_WEIGHTS = {"required": 40, "nice": 10, "similarity": 25, "experience": 15, "education": 10}

SKILL_ALIASES = {
    "javascript": ["js", "node.js", "nodejs", "ecmascript"],
    "typescript": ["ts"],
    "python": ["py", "python3"],
    "machine learning": ["ml"],
    "artificial intelligence": ["ai"],
    "postgresql": ["postgres"],
    "kubernetes": ["k8s"],
    "amazon web services": ["aws"],
    "google cloud": ["gcp", "google cloud platform"],
    "continuous integration": ["ci/cd", "ci", "cicd"],
    "natural language processing": ["nlp"],
    "react": ["react.js", "reactjs"],
    "c++": ["cpp"],
    "c#": ["csharp"],
    "golang": ["go lang"],
    "rest api": ["rest", "restful"],
}

EDU_LEVELS = {  # name -> (rank, patterns)
    "phd": (4, [r"ph\.?\s?d", r"doctorate", r"doctoral"]),
    "master": (3, [r"master", r"m\.?sc?\b", r"m\.?eng", r"mba"]),
    "bachelor": (2, [r"bachelor", r"b\.?sc?\b", r"b\.?eng", r"b\.?a\b", r"undergraduate degree"]),
    "associate": (1, [r"associate (degree|of)", r"diploma"]),
    "none": (0, []),
}

STOPWORDS = set("""a an and are as at be by for from has have in is it its of on or that the
this to was were will with you your we our they their i my me he she them us not but if
about into over than then so such can could should would may might also more most other
some any all each per via etc using used use work worked working experience experienced
responsible team teams ability strong good great excellent""".split())


# ---------- Reading files ----------
def read_resume(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in (".txt", ".md"):
        return path.read_text(encoding="utf-8", errors="ignore")
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            sys.exit("PDF support needs: pip install pypdf")
        try:
            reader = PdfReader(str(path))
            if reader.is_encrypted:
                reader.decrypt("")  # works for PDFs with an empty user password
            text = "\n".join((p.extract_text() or "") for p in reader.pages)
        except Exception as exc:  # corrupt, password-protected, etc.
            print(f"  ! Could not read {path.name}: {exc}", file=sys.stderr)
            return ""
        if len(text.split()) < 30:
            print(f"  ! {path.name}: little or no text found (scanned/image PDF? "
                  "this tool needs text-based PDFs, or OCR first)", file=sys.stderr)
        return text
    if suffix == ".docx":
        try:
            import docx
        except ImportError:
            sys.exit("DOCX support needs: pip install python-docx")
        return "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    return ""


# ---------- Text helpers ----------
def tokenize(text: str):
    words = re.findall(r"[a-z0-9+#]+", text.lower())
    return [w for w in words if w not in STOPWORDS and len(w) > 1]


def ngrams(tokens):
    return tokens + [f"{a} {b}" for a, b in zip(tokens, tokens[1:])]


def skill_regex(skill: str):
    variants = [skill.lower()] + SKILL_ALIASES.get(skill.lower(), [])
    # also let a listed alias map back to its canonical skill
    for canon, aliases in SKILL_ALIASES.items():
        if skill.lower() in aliases:
            variants += [canon] + aliases
    pattern = "|".join(re.escape(v) for v in sorted(set(variants), key=len, reverse=True))
    return re.compile(rf"(?<![\w+#])(?:{pattern})(?![\w+#])", re.IGNORECASE)


def find_skills(text: str, skills):
    found, missing = [], []
    for s in skills:
        (found if skill_regex(s).search(text) else missing).append(s)
    return found, missing


# ---------- TF-IDF cosine similarity (pure Python) ----------
def tfidf_similarities(jd_text: str, resume_texts: dict):
    docs = {"__jd__": Counter(ngrams(tokenize(jd_text)))}
    for name, txt in resume_texts.items():
        docs[name] = Counter(ngrams(tokenize(txt)))
    n = len(docs)
    df = Counter()
    for c in docs.values():
        df.update(c.keys())
    idf = {t: math.log((1 + n) / (1 + d)) + 1 for t, d in df.items()}

    def vec(c):
        v = {t: (1 + math.log(f)) * idf[t] for t, f in c.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {t: x / norm for t, x in v.items()}

    jd_vec = vec(docs["__jd__"])
    sims = {}
    for name in resume_texts:
        rv = vec(docs[name])
        small, big = (rv, jd_vec) if len(rv) < len(jd_vec) else (jd_vec, rv)
        sims[name] = sum(x * big.get(t, 0.0) for t, x in small.items())
    return sims


# ---------- Experience & education ----------
def estimate_years(text: str) -> float:
    t = text.lower()
    stated = [int(m) for m in re.findall(r"(\d{1,2})\s*\+?\s*(?:years?|yrs?)\b(?:\s+of)?\s+(?:\w+\s+){0,3}?experience", t)]
    stated += [int(m) for m in re.findall(r"experience\s*(?:of|:)?\s*(\d{1,2})\s*\+?\s*(?:years?|yrs?)", t)]

    # merge date ranges like "2018 - 2022" / "2020 - present" (skips education lines)
    spans = []
    this_year = 2026
    for line in t.splitlines():
        if re.search(r"universit|college|school|degree|b\.?sc|m\.?sc|bachelor|master|ph\.?d|mba|education", line):
            continue
        for a, b in re.findall(r"\b((?:19|20)\d{2})\s*(?:-|–|—|to)\s*((?:19|20)\d{2}|present|current|now)\b", line):
            start = int(a)
            end = this_year if b in ("present", "current", "now") else int(b)
            if 0 <= end - start <= 40:
                spans.append((start, end))
    spans.sort()
    merged = []
    for s, e in spans:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    computed = sum(e - s for s, e in merged)
    # trust an explicit "N years of experience" claim if present, else use date ranges
    return float(min(max(stated) if stated else computed, 40))


def detect_education(text: str):
    t = text.lower()
    best = ("none", 0)
    for name, (rank, pats) in EDU_LEVELS.items():
        if rank > best[1] and any(re.search(p, t) for p in pats):
            best = (name, rank)
    return best


# ---------- Scoring ----------
def score_candidate(name, text, job, sim):
    w = {**DEFAULT_WEIGHTS, **job.get("weights", {})}
    req, nice = job.get("required_skills", []), job.get("nice_to_have", [])

    req_found, req_missing = find_skills(text, req)
    nice_found, _ = find_skills(text, nice)
    req_cov = len(req_found) / len(req) if req else 1.0
    nice_cov = len(nice_found) / len(nice) if nice else 0.0

    years = estimate_years(text)
    min_years = job.get("min_years", 0)
    exp_score = 1.0 if min_years == 0 else min(years / min_years, 1.0)
    # small bonus for exceeding the minimum, capped
    if min_years and years > min_years:
        exp_score = min(1.0, exp_score)

    edu_name, edu_rank = detect_education(text)
    min_edu_rank = EDU_LEVELS.get(job.get("min_education", "none"), (0, []))[0]
    edu_score = 1.0 if min_edu_rank == 0 else min(edu_rank / min_edu_rank, 1.0)

    # TF-IDF cosine is typically low in absolute terms; stretch it for scoring
    sim_score = min(sim / 0.35, 1.0)

    total = (
        w["required"] * req_cov + w["nice"] * nice_cov + w["similarity"] * sim_score
        + w["experience"] * exp_score + w["education"] * edu_score
    ) / sum(w.values()) * 100

    flags = []
    if req and req_cov < job.get("min_required_coverage", 0.5):
        flags.append("low required-skill coverage")
    if min_years and years < min_years:
        flags.append(f"under {min_years}y experience")
    if min_edu_rank and edu_rank < min_edu_rank:
        flags.append("below education requirement")
    if len(text.split()) < 40:
        flags.append("very short/unparseable resume")

    return {
        "candidate": name,
        "score": round(total, 1),
        "required_matched": ", ".join(req_found),
        "required_missing": ", ".join(req_missing),
        "nice_matched": ", ".join(nice_found),
        "years_experience": years,
        "education": edu_name,
        "similarity": round(sim, 3),
        "flags": "; ".join(flags),
    }


def rank(job, resumes_dir: Path):
    if not resumes_dir.is_dir():
        sys.exit(f"Resumes folder not found: {resumes_dir}\n"
                 "Create a folder named 'resumes' next to this script (or pass --resumes <path>) "
                 "and put your PDF/DOCX/TXT files inside it.")
    files = sorted(p for p in resumes_dir.iterdir() if p.suffix.lower() in (".txt", ".md", ".pdf", ".docx"))
    if not files:
        sys.exit(f"No resumes found in {resumes_dir}")
    texts = {p.stem: read_resume(p) for p in files}
    jd_text = " ".join([job.get("title", ""), job.get("description", ""),
                        " ".join(job.get("required_skills", [])) * 2,
                        " ".join(job.get("nice_to_have", []))])
    sims = tfidf_similarities(jd_text, texts)
    rows = [score_candidate(n, t, job, sims[n]) for n, t in texts.items()]
    rows.sort(key=lambda r: (-r["score"], r["candidate"]))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
        r["tier"] = "Strong" if r["score"] >= 70 else "Maybe" if r["score"] >= 45 else "Weak"
    return rows


def print_table(rows, top):
    print(f"\n{'#':<3} {'Candidate':<24} {'Score':>5}  {'Tier':<6} {'Yrs':>4}  Missing required / flags")
    print("-" * 90)
    for r in rows[:top]:
        extra = r["required_missing"] or "-"
        if r["flags"]:
            extra += f"  [{r['flags']}]"
        print(f"{r['rank']:<3} {r['candidate'][:24]:<24} {r['score']:>5}  {r['tier']:<6} {r['years_experience']:>4.0f}  {extra}")


def main():
    ap = argparse.ArgumentParser(description="Resume screening and ranking tool")
    here = Path(__file__).resolve().parent  # defaults work no matter where you run from
    ap.add_argument("--job", default=str(here / "job.json"), help="Path to job JSON config")
    ap.add_argument("--resumes", default=str(here / "resumes"), help="Folder with resumes")
    ap.add_argument("--out", default=str(here / "ranking.csv"), help="CSV output path")
    ap.add_argument("--top", type=int, default=15, help="Rows to print")
    args = ap.parse_args()

    job_path = Path(args.job)
    if not job_path.is_file():
        sys.exit(f"Job file not found: {job_path}\n"
                 "Put job.json next to this script (or pass --job <path>).")
    job = json.loads(job_path.read_text(encoding="utf-8"))
    rows = rank(job, Path(args.resumes))
    print_table(rows, args.top)

    fields = ["rank", "candidate", "score", "tier", "required_matched", "required_missing",
              "nice_matched", "years_experience", "education", "similarity", "flags"]
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=fields)
        wr.writeheader()
        wr.writerows(rows)
    print(f"\nFull results saved to {args.out}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Vitulelex Talent Screening - local web server.

Run:   python server.py
Open:  http://localhost:8000

Drop PDF/DOCX/TXT resumes into the "resumes" folder; the page detects them
automatically and ranks them. Requires resume_ranker.py, job.json and index.html
in the same folder as this file.
"""
import json
import mimetypes
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import resume_ranker as rr

BASE = Path(__file__).resolve().parent
RESUMES = BASE / "resumes"
JOB_FILE = BASE / "job.json"
INDEX = BASE / "index.html"
EXTS = {".pdf", ".docx", ".txt", ".md"}


def list_files():
    RESUMES.mkdir(exist_ok=True)
    return sorted(p for p in RESUMES.iterdir() if p.is_file() and p.suffix.lower() in EXTS)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # keep the console quiet
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                if not INDEX.is_file():
                    return self.send(404, {"error": "index.html not found next to server.py"})
                return self.send(200, INDEX.read_bytes(), "text/html; charset=utf-8")
            if path == "/api/files":
                return self.send(200, [{"name": p.name, "size": p.stat().st_size,
                                        "mtime": p.stat().st_mtime} for p in list_files()])
            if path == "/api/job":
                job = json.loads(JOB_FILE.read_text(encoding="utf-8")) if JOB_FILE.is_file() else {}
                return self.send(200, job)
            if path.startswith("/resumes/"):
                f = (RESUMES / path[len("/resumes/"):]).resolve()
                if f.parent != RESUMES.resolve() or not f.is_file() or f.suffix.lower() not in EXTS:
                    return self.send(404, {"error": "not found"})
                ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
                return self.send(200, f.read_bytes(), ctype,
                                 {"Content-Disposition": f'inline; filename="{f.name}"'})
            return self.send(404, {"error": "not found"})
        except Exception as exc:
            return self.send(500, {"error": str(exc)})

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length) or b"{}")
            if path == "/api/rank":
                files = list_files()
                if not files:
                    return self.send(200, {"rows": []})
                rows = rr.rank(data, RESUMES)
                names = {}
                for p in files:
                    names.setdefault(p.stem, p.name)
                for r in rows:
                    r["file"] = names.get(r["candidate"], "")
                return self.send(200, {"rows": rows})
            if path == "/api/job":
                JOB_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
                return self.send(200, {"ok": True})
            return self.send(404, {"error": "not found"})
        except SystemExit as exc:  # resume_ranker uses sys.exit for some errors
            return self.send(500, {"error": str(exc)})
        except Exception as exc:
            return self.send(500, {"error": str(exc)})


def main():
    RESUMES.mkdir(exist_ok=True)
    for port in range(8000, 8011):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    else:
        sys.exit("Ports 8000-8010 are all busy. Close other programs and try again.")
    url = f"http://localhost:{port}"
    print(f"Vitulelex Talent Screening running at {url}")
    print(f"Watching folder: {RESUMES}")
    print("Press Ctrl+C to stop.")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
